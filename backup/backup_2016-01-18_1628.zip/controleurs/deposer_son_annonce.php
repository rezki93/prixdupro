<?php
 
//On inclut la vue
  //include(dirname(__FILE__).'/../vues/search.php');
  //$smarty->display('deposer_son_annonce.tpl');  
  
?>
<html>
  <head>
    <title>D�posez votre annonce</title>
    <meta name="Description" content="D�poser sans attendre votre petite annonce gratuitement." >
    <?php $smarty->display('templates/head1.tpl'); ?>
    
    <style>
      #bloc_choix_creation{width:770px;margin:auto;}
      
      #choix_creation_compte{float:left;border:2px solid grey;border-radius:10px;cursor:pointer;padding: 30px 0 30px 0;width:375px;}
      #choix_creation_compte:hover{background-color:#CCC;border:2px solid blue;}
     
      #choix_depot_direct{float:left;border:2px solid grey;border-radius:10px;cursor:pointer;padding: 30px 0 30px 0;width:375px;margin-left:10px}
      #choix_depot_direct:hover{background-color:#CCC;border:2px solid red;}
      
      .t300{width:360px;}
    </style>
    <! -- Mise en forme des boutons -->    
    <script type="text/javascript">
      $(function() {
        $( "#map_annonce" ).button();  
        $( "#affiche_adresse" ).button();     
        $( "#affiche_tel" ).button();  
        $( "#debat_annonce" ).button();
        
      });
    </script>
    
  </head>
  
  <body>
    <?php $smarty->display('templates/banniere.tpl'); ?>   
    
    <div id="contenu-principal" class="ui-widget-content" style="width:984px;min-height:500px;border-radius: 20px 20px 20px 20px;margin:auto;padding:20px">
      <h1 style="margin:auto;color:#52A1A0;font-size:25px" align="center" >D�pot d'annonce</h1>
      <p style="font-family:Arial,Helvetica,sans-serif;font-size:15px;margin-top:20px">
        Le dep�t d'annonce sur le site est totalement <b>GRATUIT</b>.<br/>
        Vous avez la possibilit� de cr�er autant d'annonces que vous le souhaitez. Vos annonces devront �tre valid� par nos �quipes avant d'�tre mises en ligne. Le delai maximum est de 12 heures.<br/>
        <b>N'h�sitez plus, Faites vous plaisir : Annoncez !</b>
      </p>
      
  <?php
  //Si l'utilisateur est d�j� connect�
  if(isset($_SESSION["etat"]) && $_SESSION["etat"]=="connecte" && isset($_SESSION["con_id"]) && is_numeric($_SESSION["con_id"]) ){
    ?>
       <div style="float:left;margin:30px 0 0 30px">
        <form method="POST" name="depot_annonce" enctype="multipart/form-data" action="./index.php?page=depot_annonce">
        
          
          <div id="loader" style="position:absolute; margin-left:300px;display:none">
            <img src="./images/loading.gif" >
          </div>
          
          <div id="bloc-user" style="">
            
            <div style="margin: 10px 0 0 10px">
              <div class="titre_champ" >Region :</div>
              <SELECT style="width:350px;" id="region" name="region" onchange="getDepartements(this.value,'','bloc_depot_departements');">
                <OPTION  VALUE="--">--</OPTION>
                <OPTION  VALUE="1">Alsace</OPTION>
                <OPTION  VALUE="2">Aquitaine</OPTION>
                <OPTION  VALUE="3">Auvergne</OPTION>
                <OPTION  VALUE="4">Basse-Normandie</OPTION>
                <OPTION  VALUE="5">Bourgogne</OPTION>
                <OPTION  VALUE="6">Bretagne</OPTION>
                <OPTION  VALUE="7">Centre</OPTION>
                <OPTION  VALUE="8">Champagne-Ardenne</OPTION>
                <OPTION  VALUE="9">Corse</OPTION>
                <OPTION  VALUE="10">Franche-Comt�</OPTION>
                <OPTION  VALUE="11">Haute-Normandie</OPTION>
                <OPTION  VALUE="12">Ile-de-France</OPTION>
                <OPTION  VALUE="13">Languedoc-Roussillon</OPTION>
                <OPTION  VALUE="14">Limousin</OPTION>
                <OPTION  VALUE="15">Lorraine</OPTION>
                <OPTION  VALUE="16">Midi-Pyr�n�s</OPTION>
                <OPTION  VALUE="17">Nord-Pas-De-Calais</OPTION>
                <OPTION  VALUE="18">Pays de la Loire</OPTION>
                <OPTION  VALUE="19">Picardie</OPTION>
                <OPTION  VALUE="20">Poitou-Charentes</OPTION>
                <OPTION  VALUE="21">Alpes-C�te d'Azur</OPTION>
                <OPTION  VALUE="22">Rh�ne-Alpes</OPTION>
                <OPTION  VALUE="23">Departements d'outre Mer</OPTION>    
                
              </SELECT>
            </div>  
            
            <div style="margin: 10px 0 0 10px">
              <span id="bloc_depot_departements"></span>
            </div>
            
            <div style="margin: 10px 0 0 10px">
              <div class="titre_champ" >Ville :</div>
              <input type="text" class="zone-saisie" style="width:350px;" maxlength="50" id="ville_annonce" name="ville_annonce"  value="" />
            </div>
          </div>
          
          
          <div style="margin: 10px 0 0 10px">
            <div class="titre_champ">Categorie :</div>
            <SELECT style="width:350px;" id="cat_annonce" name="cat_annonce"  value="">
              <OPTION  VALUE="--">Toutes</OPTION>
              <optgroup label="Vehicules">
                <OPTION VALUE="1">Auto</OPTION>
                <OPTION VALUE="2">Moto</OPTION>
                <OPTION VALUE="3">Caravaning</OPTION>
                <OPTION VALUE="4">Utilitaires</OPTION>
                <OPTION VALUE="5">Equipement Auto</OPTION>
                <OPTION VALUE="6">Equipement Moto</OPTION>
                <OPTION VALUE="7">Equipement Caravaning</OPTION>
              </optgroup>
              
              
              <optgroup label="Hi-Tech">
                <OPTION VALUE="34">Image/Son</OPTION>
                <OPTION VALUE="9">Informatique</OPTION>
                <OPTION VALUE="10">Consoles/Jeux video</OPTION>
                <OPTION VALUE="11">Telephonie</OPTION>
              </optgroup>
              
              <optgroup label="Maison">
                <OPTION VALUE="8">Immobilier</OPTION>
                <OPTION VALUE="12">Ameublement</OPTION>
                <OPTION VALUE="13">Electromenager</OPTION>
                <OPTION VALUE="14">Decoration</OPTION>
                <OPTION VALUE="15">Bricolage/Jardinage</OPTION>
                <OPTION VALUE="16">Vetements</OPTION>
                <OPTION VALUE="17">Accessoire/Bagagerie</OPTION>
                <OPTION VALUE="18">Montres/Bijoux</OPTION>
                <OPTION VALUE="19">Equipement Bebe</OPTION>
              </optgroup>
              
              <optgroup label="Loisirs">
                <OPTION VALUE="20">DVD</OPTION>
                <OPTION VALUE="21">CD</OPTION>
                <OPTION VALUE="22">Bluray</OPTION>
                <OPTION VALUE="23">Livres</OPTION>
                <OPTION VALUE="24">Animaux</OPTION>
                <OPTION VALUE="25">Sports/Hobbies</OPTION>
                <OPTION VALUE="26">Collection</OPTION>
                <OPTION VALUE="27">Jeux/Jouets</OPTION>
                <OPTION VALUE="28">Vins/Gastronomie</OPTION>
              </optgroup>
              
              <optgroup label="Emplois & services">
                <OPTION VALUE="29">Billeterie</OPTION>
                <OPTION VALUE="30">Evenements</OPTION>
                <OPTION VALUE="31">Services</OPTION>
                <OPTION VALUE="32">Emplois</OPTION>
                <OPTION VALUE="33">Cours Particuliers</OPTION>
              </optgroup>
              <OPTION VALUE="35">Autre</OPTION>
              
            </SELECT>
          </div>
          
          
          <div style="margin: 10px 0 0 10px">
            <div class="titre_champ">Titre annonce :</div>
            <input type="text" class="zone-saisie" style="width:350px;" maxlength="30" id="titre_annonce" name="titre_annonce"  value="" />
          </div>
          
          <div style="margin: 10px 0 0 10px">
            <div class="titre_champ">Prix :</div>
            <input type="text" class="zone-saisie" style="width:200px;" id="prix_annonce" name="prix_annonce" onclick="" value="" />
          </div>
          
          <div id="bloc_auto" style="">
            <div id="bloc_depot_annee" style="float:left;margin-left:10px;display:none">
              <div style="float:left;margin: 3px;width:40px">Annee :</div>
              <input type="text" class="zone-saisie" style="width:50px;" id="annee_annonce" name="annee_annonce" onclick="" value="" />
            </div>
            
            <div id="bloc_depot_km" style="float:left;margin-left:10px;display:none">
              <div style="float:left;margin: 3px;width:25px">Km :</div>
              <input type="text" class="zone-saisie" style="width:50px;" id="km_annonce" name="km_annonce" onclick="" value="" />
            </div>
            
            <div id="bloc_depot_energie" style="float:left;margin-left:10px;display:none">
              <div style="float:left;margin: 3px;width:45px">Energie :</div>
              <SELECT style="width:50px;" id="energie_annonce" name="energie_annonce" >
                <OPTION id="" VALUE="--">--</OPTION>
                <OPTION id="" VALUE="Diesel">Diesel</OPTION>
                <OPTION id="" VALUE="Essence">Essence</OPTION>
                <OPTION id="" VALUE="Electrique">Electrique</OPTION>
                <OPTION id="" VALUE="GPL">GPL</OPTION>
              </SELECT>
            </div>
            
            <div id="bloc_depot_boite" style="float:left;margin-left:10px;display:none">
              <div style="float:left;margin: 3px;width:35px">Boite :</div>
              <SELECT style="width:50px;" id="boite_annonce" name="boite_annonce" >
                <OPTION id="" VALUE="--">--</OPTION>
                <OPTION id="" VALUE="Automatique">Automatique</OPTION>
                <OPTION id="" VALUE="Manuelle">Manuelle</OPTION>
              </SELECT>
            </div>
            
          </div>
          
          
          <div id="bloc_description" style="margin: 10px 0 0 10px">
            <div class="titre_champ">Description :</div>    
            <TEXTAREA width="600px" id="desc_annonce" name="desc_annonce" onkeyup="this.value = this.value.substr(0,2000);" >
            </TEXTAREA>
          </div>
          
          <div style="margin: 10px 0 0 10px">
            <div class="titre_champ">Pseudo :</div>
            <input type="text" class="zone-saisie" style="width:250px;" maxlength="30" id="pseudo_annonce" name="pseudo_annonce"  value="" />
          </div>
          
          <div style="margin: 10px 0 0 10px">
            <div class="titre_champ">Email :</div>
            <input type="text" class="zone-saisie" style="width:250px;" id="email_annonce" name="email_annonce" onclick="" value="" />
          </div>
          
          <div style="margin: 10px 0 0 10px">
            <div class="titre_champ">T�l�phone :</div>
            <input type="text" class="zone-saisie" style="width:250px;" maxlength="30" id="tel_annonce" name="tel_annonce"  value="" />
          </div>
          
          <div style="margin: 10px 0 0 10px">
            <div class="titre_champ" >Mot de passe :</div>
            <input type="password" class="zone-saisie" style="width:250px;" id="mdp_annnonce" name="mdp_annonce" />
          </div>
          
          
          <div style="width:450px;height:100px">  
            <div style="margin-left:10px;margin-top:20px;float:left;">
              <div style="float:left;margin: 3px;width:300px">Vous souhaitez activer la localisation Google Map :</div>
              <input style="float:left" type="checkbox" id="map_annonce" name="map_annonce"  checked="checked" />
            </div>
            
            <div style="margin-left:10px;float:left">
              <div style="float:left;margin: 3px;width:300px">Votre adresse compl�te est divulg�e:</div>
              <input style="float:left" type="checkbox" id="affiche_adresse" name="affiche_adresse" checked="checked" />
            </div>
            
            <div style="margin-left:10px;float:left">
              <div style="float:left;margin: 3px;width:300px">Votre prix est � d�battre :</div>
              <input style="float:left" type="checkbox" id="debat_annonce" name="debat_annonce"  />
            </div>
            
            <div style="margin-left:10px;float:left">
              <div style="float:left;margin: 3px;width:300px">Vous souhaitez afficher votre num�ro de t�l�phone :</div>
              <input style="float:left" type="checkbox" id="affiche_tel" name="affiche_tel" checked="checked" />
            </div>
            
          </div>
          
          <div id="bloc_photos" style="width:250;margin-top:30px">
            <div style="margin-left:10px">
              <div style="margin: 3px;width:210px">Les photos ne doivent pas depasser 2mo</div>
            </div>
            
            <div id="bloc_photo1" style="margin-left:10px">
              <div style="margin: 3px;width:80px">Photo 1:</div>
              <input type="file" name="photo1" id="photo1" />
              <input type="hidden" name="MAX_FILE_SIZE" value="10097152" />  
            </div>
            
            <div id="bloc_photo2" style="margin-left:10px;display:none">
              <div style="margin: 3px;width:80px">Photo 2:</div>
              <input type="file" name="photo2" id="photo2" />
              <input type="hidden" name="MAX_FILE_SIZE" value="10097152" />  
            </div>
            
            <div id="bloc_photo3" style="margin-left:10px;display:none">
              <div style="margin: 3px;width:80px">Photo 3:</div>
              <input type="file" name="photo3" id="photo3" />
              <input type="hidden" name="MAX_FILE_SIZE" value="10097152" />  
            </div>
            
          </div>        
          
          <div id="indication_erreurs2" style="float:left;color:#CA0036;display:none;border:2px solid red;border-radius:10px; width:800px;padding:5px ">
            <div><b>Veuillez verifier que :</b></div>
            <div>- les champs soient remplis</div>
            <div>- la categorie soit selectionn�e</div>
            <div>- le prix soit un chiffre (sans le ?)</div>
          </div>
          
          <div style="width:950px;">
            <div class="blue-button2" id="deposer_annonce" style="margin-right:0px;margin-bottom: 10px;">Deposer Annonce</div>
          </div>
        
        </form>
      </div>
        <div class="clear"></div>
      

  
<?php
  }
  /* Si l'utilisateur n'est pas connect� */
  else{
    ?>
    <div id="bloc_choix_creation" align=center >
      <div id="choix_creation_compte" style="" onclick="if($('#form_creation_compte').is(':hidden')){$('#form_depot_direct').slideUp();$('#form_creation_compte').slideDown('');}">
        <span style="font-size:18px">Se cr�er un compte Annonceur</span>        
      </div>
      
      <div id="choix_depot_direct" style="" onclick="if($('#form_depot_direct').is(':hidden')){$('#form_creation_compte').slideUp();$('#form_depot_direct').slideDown('');}">
         <span style="font-size:18px">D�poser son Annonce sans compte</span>      
      </div>
    </div>
    
      <div class="clear"></div>
      
      <div id="form_creation_compte" style="width:750px;margin:auto;padding:10px;border:2px solid blue;border-radius:10px">
        <form method="POST" name="creation_compte" action="./index.php?page=inscription">
          <div style="float:left">
            <div class="t300" style="margin-left:10px">
              <div style="float:left;margin: 3px;width:100px">Prenom :</div>
              <input type="text" class="zone-saisie" style="width:150px;" maxlength="40" id="prenom" name="prenom"  value="" />
            </div>
            
            <div class="t300" style="margin-left:10px">
              <div style="float:left;margin: 3px;width:100px">Nom :</div>
              <input type="text" class="zone-saisie" style="width:150px;" maxlength="40" id="nom" name="nom"  value="" />
            </div>
            
            <div class="t300" style="margin-left:10px">
              <div style="float:left;margin: 3px;width:100px">Tel :</div>
              <input type="text" class="zone-saisie" style="width:150px;" id="tel" name="tel" value="" />
            </div>
            
   
            <div class="t300" style="margin-left:10px">
              <div style="float:left;margin: 3px;width:100px">Region :</div>
              <SELECT style="float:left;width:150px;" id="region" name="region" onchange="getDepartements(this.value,'','bloc_depot_departements');">
                <OPTION  VALUE="--">--</OPTION>
                <OPTION  VALUE="1">Alsace</OPTION>
                <OPTION  VALUE="2">Aquitaine</OPTION>
                <OPTION  VALUE="3">Auvergne</OPTION>
                <OPTION  VALUE="4">Basse-Normandie</OPTION>
                <OPTION  VALUE="5">Bourgogne</OPTION>
                <OPTION  VALUE="6">Bretagne</OPTION>
                <OPTION  VALUE="7">Centre</OPTION>
                <OPTION  VALUE="8">Champagne-Ardenne</OPTION>
                <OPTION  VALUE="9">Corse</OPTION>
                <OPTION  VALUE="10">Franche-Comt�</OPTION>
                <OPTION  VALUE="11">Haute-Normandie</OPTION>
                <OPTION  VALUE="12">Ile-de-France</OPTION>
                <OPTION  VALUE="13">Languedoc-Roussillon</OPTION>
                <OPTION  VALUE="14">Limousin</OPTION>
                <OPTION  VALUE="15">Lorraine</OPTION>
                <OPTION  VALUE="16">Midi-Pyr�n�s</OPTION>
                <OPTION  VALUE="17">Nord-Pas-De-Calais</OPTION>
                <OPTION  VALUE="18">Pays de la Loire</OPTION>
                <OPTION  VALUE="19">Picardie</OPTION>
                <OPTION  VALUE="20">Poitou-Charentes</OPTION>
                <OPTION  VALUE="21">Alpes-C�te d'Azur</OPTION>
                <OPTION  VALUE="22">Rh�ne-Alpes</OPTION>
                <OPTION  VALUE="23">Departements d'outre Mer</OPTION>    
              </SELECT>
            </div>  
              
            <div class="t300" style="margin-left:10px" >
              <div class="" style="float:left;margin: 3px;width:100px">Departement :</div>
              <span id="bloc_depot_departements" style="width:150px">
                <input type="text" class="zone-saisie" style="width:150px;" maxlength="50" id="departement" name="departement"  value="" />
              </span>
            </div>
   
            <div class="t300" style="margin-left:10px;float:left">
              <div class="" style="float:left;margin: 3px;width:100px">Ville :</div>
              <input type="text" class="zone-saisie" style="width:150px;" maxlength="50" id="ville" name="ville"  value="" />
            </div>
            
            <div class="t300" style="margin-left:10px">
              <div class="" style="float:left;margin: 3px;width:100px">Adresse :</div>
              <input type="text" class="zone-saisie" style="width:150px;" maxlength="50" id="adresse" name="adresse"  value="" />
            </div>

                    
            <div class="t300" style="margin-left:10px">
              <div class="" style="float:left;margin: 3px;width:100px">E-mail :</div>
              <input type="text" class="zone-saisie" style="width:150px;" id="mail" name="mail"  value="" />
            </div>
            
            <div class="t300" style="margin-left:10px">
              <div class="" style="float:left;margin: 3px;width:100px">Mot de passe :</div>
              <input type="password" class="zone-saisie" style="width:150px;" id="password" name="password" />
            </div>
          </div>
          
          <div id="indication_erreurs" style="float:left;margin-left:30px;color:#CA0036;display:none">
            <div><b>Veuillez verifier que :</b></div>
            <div>- les champs soient remplis</div>
            <div>- le numero de telephone poss�de 10 chiffres</div>
            <div>- l'adresse mail soit valide</div>
            <div>- le mot de passe poss�de au moins 6 caract�res</div>
          </div>
          
          <div class="clear"></div>
          <div class="blue-button2" id="inscription" style="margin-right:0px;margin-top:10px;">S'inscrire</div>
        </form>
        <div class="clear"></div>
      </div>
      
      <div class="clear"></div>
      
      <div id="form_depot_direct"  style="width:750px;margin:auto;padding:10px;border:2px solid red;border-radius:10px;display:none;">
        <form method="POST" name="form_depot_direct" enctype="multipart/form-data" action="index.php?page=deposer_son_annonce" >
          <div id="bloc_desc_user1" style="float:left;margin-left:10px;border:1px solid grey">
            <div class="t300" >
              <div style="float:left;margin: 3px;width:100px">Pseudo :</div>
              <input type="text" class="zone-saisie" style="width:150px;" maxlength="40" id="prenom" name="prenom"  value="" />
            </div>
            
            <div class="t300">
              <div style="float:left;margin: 3px;width:100px">Tel :</div>
              <input type="text" class="zone-saisie" style="width:150px;" id="tel" name="tel" value="" />
            </div>
            
            <div class="t300">
              <div class="" style="float:left;margin: 3px;width:100px">E-mail :</div>
              <input type="text" class="zone-saisie" style="width:150px;" id="mail" name="mail"  value="" />
            </div>
            
            <div class="t300" >
              <div class="" style="float:left;margin: 3px;width:100px">Mot de passe :</div>
              <input type="password" class="zone-saisie" style="width:150px;" id="password" name="password" />
            </div>      
          </div> 
          <!-- fin id="bloc_desc_user1" -->          
          
          <div id="bloc_desc_user2" style="float:left;border:1px solid green">   
            <div class="t300" >
              <div style="float:left;margin: 3px;width:100px">Region :</div>
              <SELECT style="float:left;width:150px;" id="region" name="region" onchange="getDepartements(this.value,'','bloc_depot_departements');">
                <OPTION  VALUE="--">--</OPTION>
                <OPTION  VALUE="1">Alsace</OPTION>
                <OPTION  VALUE="2">Aquitaine</OPTION>
                <OPTION  VALUE="3">Auvergne</OPTION>
                <OPTION  VALUE="4">Basse-Normandie</OPTION>
                <OPTION  VALUE="5">Bourgogne</OPTION>
                <OPTION  VALUE="6">Bretagne</OPTION>
                <OPTION  VALUE="7">Centre</OPTION>
                <OPTION  VALUE="8">Champagne-Ardenne</OPTION>
                <OPTION  VALUE="9">Corse</OPTION>
                <OPTION  VALUE="10">Franche-Comt�</OPTION>
                <OPTION  VALUE="11">Haute-Normandie</OPTION>
                <OPTION  VALUE="12">Ile-de-France</OPTION>
                <OPTION  VALUE="13">Languedoc-Roussillon</OPTION>
                <OPTION  VALUE="14">Limousin</OPTION>
                <OPTION  VALUE="15">Lorraine</OPTION>
                <OPTION  VALUE="16">Midi-Pyr�n�s</OPTION>
                <OPTION  VALUE="17">Nord-Pas-De-Calais</OPTION>
                <OPTION  VALUE="18">Pays de la Loire</OPTION>
                <OPTION  VALUE="19">Picardie</OPTION>
                <OPTION  VALUE="20">Poitou-Charentes</OPTION>
                <OPTION  VALUE="21">Alpes-C�te d'Azur</OPTION>
                <OPTION  VALUE="22">Rh�ne-Alpes</OPTION>
                <OPTION  VALUE="23">Departements d'outre Mer</OPTION>    
              </SELECT>
            </div>  
              
            <div class="t300" >
              <div class="" style="float:left;margin: 3px;width:100px">Departement :</div>
              <span id="bloc_depot_departements" style="width:150px">
                <input type="text" class="zone-saisie" style="width:150px;" maxlength="50" id="departement" name="departement"  value="" />
              </span>
            </div>
   
            <div class="t300" >
              <div class="" style="float:left;margin: 3px;width:100px">Ville :</div>
              <input type="text" class="zone-saisie" style="width:150px;" maxlength="50" id="ville" name="ville"  value="" />
            </div>
            
            <div class="t300" >
              <div class="" style="float:left;margin: 3px;width:100px">Adresse :</div>
              <input type="text" class="zone-saisie" style="width:150px;" maxlength="50" id="adresse" name="adresse"  value="" />
            </div>      
          </div> 
          <!-- fin id="bloc_desc_user2" -->  
          
          <div class="clear"></div>
          
          <div id="bloc_desc_user3" class="t300" style="margin-top:20px;margin-left:10px;float:left;border:1px solid orange">   
            <div id="loader" style="position:absolute; margin-left:300px;display:none">
               <img src="/images/loading.gif" >
            </div>
        
            <div class="t300">
               <div class="" style="float:left;margin: 3px;width:100px">Titre</div>
               <input type="text" class="zone-saisie" style="width:150px;" maxlength="40" id="titre_annonce" name="titre_annonce"  value="" />
            </div>
        
            <div class="t300">
               <div class="" style="float:left;margin: 3px;width:100px">Prix</div>
               <input type="text" class="zone-saisie" style="width:150px;" id="prix_annonce" name="prix_annonce" onclick="" value="" />
             </div>
        
             <div class="t300">
               <div class="" style="float:left;margin: 3px;width:100px">Categorie</div>
               <SELECT style="width:150px;" id="cat_annonce" name="cat_annonce"  value="">
                 <OPTION  VALUE="--">Toutes</OPTION>
                 <optgroup label="Vehicules">
                   <OPTION VALUE="1">Auto</OPTION>
                   <OPTION VALUE="2">Moto</OPTION>
                   <OPTION VALUE="3">Caravaning</OPTION>
                   <OPTION VALUE="4">Utilitaires</OPTION>
                   <OPTION VALUE="5">Equipement Auto</OPTION>
                   <OPTION VALUE="6">Equipement Moto</OPTION>
                   <OPTION VALUE="7">Equipement Caravaning</OPTION>
                 </optgroup>
                 
                 
                 <optgroup label="Hi-Tech">
                   <OPTION VALUE="8">Image/Son</OPTION>
                   <OPTION VALUE="9">Informatique</OPTION>
                   <OPTION VALUE="10">Consoles/Jeux video</OPTION>
                   <OPTION VALUE="11">Telephonie</OPTION>
                 </optgroup>
                 
                 <optgroup label="Maison">
                   <OPTION VALUE="12">Immobilier</OPTION>
                   <OPTION VALUE="13">Ameublement</OPTION>
                   <OPTION VALUE="14">Electromenager</OPTION>
                   <OPTION VALUE="15">Bricolage/Jardinage</OPTION>
                   <OPTION VALUE="16">Vetements</OPTION>
                   <OPTION VALUE="17">Accessoire/Bagagerie</OPTION>
                   <OPTION VALUE="18">Montres/Bijoux</OPTION>
                   <OPTION VALUE="19">Equipement Bebe</OPTION>
                 </optgroup>
                 
                 <optgroup label="Loisirs">
                   <OPTION VALUE="20">DVD</OPTION>
                   <OPTION VALUE="21">CD</OPTION>
                   <OPTION VALUE="22">Bluray</OPTION>
                   <OPTION VALUE="23">Livres</OPTION>
                   <OPTION VALUE="24">Animaux</OPTION>
                   <OPTION VALUE="25">Sports/Hobbies</OPTION>
                   <OPTION VALUE="26">Collection</OPTION>
                   <OPTION VALUE="27">Jeux/Jouets</OPTION>
                   <OPTION VALUE="28">Vins/Gastronomie</OPTION>
                 </optgroup>
                 
                 <optgroup label="Emplois & services">
                   <OPTION VALUE="29">Billeterie</OPTION>
                   <OPTION VALUE="30">Evenements</OPTION>
                   <OPTION VALUE="31">Services</OPTION>
                   <OPTION VALUE="32">Emplois</OPTION>
                   <OPTION VALUE="33">Cours Particuliers</OPTION>
                 </optgroup>
                 <OPTION VALUE="34">Recherche</OPTION>
                 <OPTION VALUE="35">Autre</OPTION>
                 
               </SELECT>
             </div>
          </div>
          <!-- fin id="bloc_desc_user3" --> 
          
          <div id="bloc_auto" style="float:left;margin-top:20px;border:1px solid black">
            <div id="bloc_depot_annee" class="t300" style="display:none;">
              <div class="" style="float:left;margin: 3px;width:100px">Annee</div>
              <input type="text" class="zone-saisie" style="width:150px;" id="annee_annonce" name="annee_annonce" onclick="" value="" />
            </div>
            
            <div id="bloc_depot_km" class="t300" style="display:none;">
              <div class="" style="float:left;margin: 3px;width:100px">Km</div>
              <input type="text" class="zone-saisie" style="width:150px;" id="km_annonce" name="km_annonce" onclick="" value="" />
            </div>
            
            
            <div id="bloc_depot_energie" class="t300" style="display:none;">
              <div class="" style="float:left;margin: 3px;width:100px">Energie</div>
              <SELECT style="width:150px;" id="energie_annonce" name="energie_annonce" >
                <OPTION id="" VALUE="--">--</OPTION>
                <OPTION id="" VALUE="Diesel">Diesel</OPTION>
                <OPTION id="" VALUE="Essence">Essence</OPTION>
                <OPTION id="" VALUE="Electrique">Electrique</OPTION>
                <OPTION id="" VALUE="GPL">GPL</OPTION>
              </SELECT>
            </div>
            
            <div id="bloc_depot_boite" class="t300" style="display:none;">
              <div class="" style="float:left;margin: 3px;width:100px">Boite</div>
              <SELECT style="width:150px;" id="boite_annonce" name="boite_annonce" >
                <OPTION id="" VALUE="--">--</OPTION>
                <OPTION id="" VALUE="Automatique">Automatique</OPTION>
                <OPTION id="" VALUE="Manuelle">Manuelle</OPTION>
              </SELECT>
            </div>
            
          </div>
          <!-- fin id="bloc_auto" -->  
          
          <div class="clear"></div>
      
          <div id="bloc_description"  style="margin-left:10px;">
            <div style="float:left" class="t300"  style="">
              <div style="margin: 3px;width:100px">Description</div>
              <div style="">
                <TEXTAREA width="200px" id="desc_annonce" name="desc_annonce" onkeyup="this.value = this.value.substr(0,2000);" >
                </TEXTAREA>
              </div>
            </div>

            <div id="bloc_visibilite" class="t300" style="border:1px solid blue;float:left;text-align:center">
              Cliquez sur une mention pour la desactiver :
              <div style="">
                <!--<div style="float:left">Afficher votre telephone :</div>-->
                <input style="" type="checkbox" id="affiche_tel" name="affiche_tel" checked="checked" />
                <label for="affiche_tel" style="width:250px;">Affichage de votre t�l�phone</label>
              </div>
              
              <div style="">
                <!--<div style="float:left">Prix � d�battre :</div>-->
                <input style="" type="checkbox" id="debat_annonce" name="debat_annonce" checked="checked"  />
                <label for="debat_annonce" style="width:250px;">Prix � d�battre</label>
              </div>
              
              
              <div style="">
                <!--<div style="float:left;">Localisation Google Map :</div>-->
                <input style="" type="checkbox" id="map_annonce" name="map_annonce" checked="checked" />
                <label for="map_annonce" style="width:250px;">Localisation Google Map de votre ville</label>
              </div>
              
              <div style="">
                <!--<div style="float:left">Localisation avec votre adresse exact:</div>-->
                <input style="" type="checkbox" id="affiche_adresse" name="affiche_adresse" checked="checked" />
                <label for="affiche_adresse" style="width:250px;">Localisation Google Map de votre adresse</label>
              </div>
            </div>
            <div class="clear"></div>
          </div>
          <!-- Fin bloc description -->
          
          <div id="bloc_photos" style="margin-left:10px;border:1px solid yellow">
            <div id="bloc_photo1" style="margin-left:30px">
              <div style="margin: 3px;width:80px">Photo 1</div>
              <input type="file" name="photo1" id="photo1" />
              <input type="hidden" name="MAX_FILE_SIZE" value="10097152" />  
            </div>
            
            <div id="bloc_photo2" style="margin-left:30px;display:none">
              <div style="margin: 3px;width:80px">Photo 2</div>
              <input type="file" name="photo2" id="photo2" />
              <input type="hidden" name="MAX_FILE_SIZE" value="10097152" />  
            </div>
            
            <div id="bloc_photo3" style="margin-left:30px;display:none">
              <div style="margin: 3px;width:80px">Photo 3</div>
              <input type="file" name="photo3" id="photo3" />
              <input type="hidden" name="MAX_FILE_SIZE" value="10097152" />  
            </div>
            <script type="text/javascript">
              $('#photo1').customFileInput();  
            </script>
            
            <div style="margin-left:30px">
              <div style="margin: 3px;width:230px">Les photos ne doivent pas depasser 4mo</div>
            </div>
          </div>
          <!-- Fin bloc photos -->

         
          
          <div  >
             <div id="indication_erreurs2" style="float:left;color:#CA0036;display:none;">
               <div><b>Veuillez v&eacute;rifier que :</b></div>
               <div>- Les champs soient remplis</div>
               <div>- La cat&eacute;gorie soit selectionn&eacute;e</div>
               <div>- Le prix soit un chiffre (sans le &#x20AC;)</div>
            </div>
            
            <div id="indication_erreurs" style="float:left;margin-left:30px;color:#CA0036;display:none">
              <div><b>Veuillez verifier que :</b></div>
              <div>- les champs soient remplis</div>
              <div>- le numero de telephone poss�de 10 chiffres</div>
              <div>- l'adresse mail soit valide</div>
              <div>- le mot de passe poss�de au moins 6 caract�res</div>
            </div>
            <div class="blue-button2" id="deposer_annonce" style="">Deposer</div>
          </div>
          <div class="clear"></div>
        </form>
      </div>
    <?php
  }
  ?>
      </div>  
  <?php
  $smarty->display('templates/footer.tpl');
  ?>

  </body>
</html>



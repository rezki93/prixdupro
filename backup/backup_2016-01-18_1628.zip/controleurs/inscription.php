<?php

//On inclut le mod�le
include(dirname(__FILE__).'/../modeles/inscription.php');
 
//On inscrit l'utilisateur
$user = inscrire_user();

//si inscription valide alors on envoi un mail
if($user['reponse'] == 1){
  require_once 'libs/Swift-4.1.0/lib/swift_required.php';
    
    $mail = $user['mail'];
    $nom = 'Prixdupro';
    $from = 'info@prixdupro.fr';
    $subject = "Nouveau compte sur Prixdupro";

    $msg ="  <b>F&eacute;licitation</b> ".$user['prenom']." ".$user['nom'].",<br> votre compte vendeur sur Prixdupro.fr &agrave; &eacute;t&eacute; cr&eacute;&eacute; avec succ&egrave;s
      <br><br>Voici les informations concernant votre compte : 
      <br><br>login : ".$user['mail']."<br>Mot de passe : ".$user['password']."
      <br><br>Bonne journ&eacute;e et bonne chance pour vos ventes.
      <br><br><img src='http://www.prixdupro.fr/images/banniere prixdupro.gif' />
      " ;
    
    //Create the message
    $message = Swift_Message::newInstance()
    ->setSubject($subject)
    ->setFrom(array($from => $nom))
    ->setTo(array($mail))
    ->setBody($msg, 'text/html')
    ;

    $transport = Swift_MailTransport::newInstance();
    $mailer = Swift_Mailer::newInstance($transport);
    $result = $mailer->send($message);

}



//On inclut la vue
include(dirname(__FILE__).'/../vues/inscription.php');


?>
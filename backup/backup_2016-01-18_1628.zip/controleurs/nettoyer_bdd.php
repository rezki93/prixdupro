<?php
  
//On inclut le mod�le
include(dirname(__FILE__).'/../modeles/nettoyer_bdd.php');

nettoyer();
 
?>
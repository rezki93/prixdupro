<?php

//On inclut le mod�le
include(dirname(__FILE__).'/../modeles/deconnexion.php');

header("Location: recherche");  
?>
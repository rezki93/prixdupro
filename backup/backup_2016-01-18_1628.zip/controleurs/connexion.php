<?php
	include(dirname(__FILE__).'/../modeles/connexion.php');
	$results = connecte_user($_POST['con_login'],$_POST['con_password']);
	header("Location: gestion");  //url rewritte htacess
?>
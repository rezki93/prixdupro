<?php

//On inclut le mod�le
include(dirname(__FILE__).'/../modeles/supprimer_annonce.php');
supprimer_annonce();
header("Location: gestion");  //url rewritte htacess

?>
<?php

	if($_SERVER['HTTP_HOST'] == 'prixdupro.free.fr'){
		$Server = 'prixdupro.sql.free.fr';
		$User = 'prixdupro';
		$Namebdd = 'prixdupro';
		$mdp = '757875';
	}
	else{
		$Server = "mysql51-57.perso";
		$User = "prixduprobdd";
		$Namebdd = "prixduprobdd";
		$mdp = "7HVtkcLW";
	}
  
	mysql_connect($Server, $User, $mdp);
	mysql_select_db($Namebdd);


    $date_now = date('Y\-m\-d H:i:s');
    $date_12mois_avant = date('Y\-m\-d H:i:s', strtotime('-12 month'));
    $annonces = array();
    
    $chaine = "SELECT distinct titre_annonce, id_annonce , date_annonce
        FROM ANNONCES
        WHERE '".$date_10mois_avant."'  > ANNONCES.date_annonce";
        
    $req = mysql_query($chaine);
	
    while ($data = mysql_fetch_assoc($req))
        $annonces[] = $data;
        
 
    echo '<br> On supprime les annonces suivantes :';
	
    foreach($annonces as $a){
      echo '<br> annonce numero :'.$a['id_annonce'];
      expirer_annonce_script($a['id_annonce']);
    }
    

function expirer_annonce_script($ref){
	$tab = Array();
    $chaine = "select ANNONCES.id_annonce, ANNONCES.id_user
    FROM USERS,ANNONCES
    WHERE USERS.id_user = ANNONCES.id_user
    AND ANNONCES.id_annonce = '".$ref."'"
    ;
    $req = mysql_query($chaine);
    while ($data = mysql_fetch_assoc($req))
        {
            $tab['infos'] = $data;
        }
      
    $chaine="UPDATE ANNONCES set etat_annonce = 'expiree'
	WHERE ANNONCES.id_annonce ='".$ref."'";
    $req = mysql_query($chaine);
}


?>